function changeParagraph() {
  document.getElementById("wiersz").innerHTML = "zmieniono za pomoca funkcji ze 'Script.js'";
}